<?php

/**
 * Plugin Name: Dienstplan Verwaltung
 * Plugin URI: https://vereinsring-wasserlos.de
 * Description: Moderne Dienstplan-Verwaltung für Vereine und Veranstaltungen
 * Version:           0.9.6.5
 * Author: Kai Naumann
 * Author URI: https://vereinsring-wasserlos.de
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: dienstplan-verwaltung
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * 
 * @package Dienstplan_Verwaltung
 */

if (!defined('ABSPATH')) {
    exit;
}

// WP 6.7+: Verhindert Header-Probleme, falls die Textdomain in seltenen
// Bootstrap-Pfaden vor init beruehrt wird.
add_filter('doing_it_wrong_trigger_error', function ($trigger, $function_name, $message) {
    if ($function_name === '_load_textdomain_just_in_time' && is_string($message) && strpos($message, 'dienstplan-verwaltung') !== false) {
        return false;
    }

    return $trigger;
}, 10, 3);

// WP/PHP 8.1+: Sicherstellen, dass Admin-Titel nie null ist (verhindert strip_tags(null)-Deprecation).
add_filter('admin_title', function ($admin_title, $title) {
    return (string) ($admin_title ?? $title ?? '');
}, PHP_INT_MAX, 2);

/**
 * Plugin-Konstanten
 */
define('DIENSTPLAN_VERSION', '0.9.6.5');
define('DIENSTPLAN_PLUGIN_FILE', __FILE__);
define('DIENSTPLAN_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('DIENSTPLAN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DIENSTPLAN_DB_PREFIX', 'dp_');

// Paket A: optionale Module standardmäßig deaktivieren.
if (!defined('DIENSTPLAN_FEATURE_UPDATER')) {
    define('DIENSTPLAN_FEATURE_UPDATER', false);
}
if (!defined('DIENSTPLAN_FEATURE_MAIL')) {
    define('DIENSTPLAN_FEATURE_MAIL', true);
}
if (!defined('DIENSTPLAN_FEATURE_NOTIFICATIONS')) {
    define('DIENSTPLAN_FEATURE_NOTIFICATIONS', false);
}
if (!defined('DIENSTPLAN_SLIM_MODE')) {
    define('DIENSTPLAN_SLIM_MODE', true);
}

/**
 * Plugin-Aktivierung
 */
function activate_dienstplan_verwaltung()
{
    require_once DIENSTPLAN_PLUGIN_PATH . 'includes/class-activator.php';
    Dienstplan_Activator::activate();
}

/**
 * Plugin-Deaktivierung
 */
function deactivate_dienstplan_verwaltung()
{
    require_once DIENSTPLAN_PLUGIN_PATH . 'includes/class-deactivator.php';
    Dienstplan_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_dienstplan_verwaltung');
register_deactivation_hook(__FILE__, 'deactivate_dienstplan_verwaltung');

/**
 * Haupt-Plugin-Klasse laden
 */
require_once DIENSTPLAN_PLUGIN_PATH . 'includes/class-dienstplan-verwaltung.php';

/**
 * Plugin ausführen
 *
 * @since    1.0.0
 */
function run_dienstplan_verwaltung()
{
    $plugin = new Dienstplan_Verwaltung();
    $plugin->run();
}

run_dienstplan_verwaltung();
